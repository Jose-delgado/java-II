/*************************************************************************
 *Purpose:     adds, subtracts, multiplies and divides the complex numbers
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        10/13/2017  
 *************************************************************************   
 */
//begin of class that implements Cloneable
public class Complex implements Cloneable {
   //data fields
	double real;
	double imaginary;
   
   //argument constructor sets variables to double type variables
	public Complex(double a, double b) {
		real = a;
		imaginary = b;
	}//end of method

	//argument constructor that sets new variables
	public Complex(double a) {
		real = a;
		imaginary = 0;
	}//end of method

	//no argument constuctor 
	public Complex() {
	}//end of constructor

	//getter for real number
	public double getRealPart() {
		return real;
	}//end of getter

	//getter for imaginary number
	public double getImaginaryPart() {
		return imaginary;
	}//end of gettet

	//Add a complex number to this complex number
	public Complex add(Complex b) {
		Complex sum = new Complex();
		sum.real = real + b.real;
		sum.imaginary = imaginary + b.imaginary;
		return sum;
	}//end of method

	//subtracts a complex number to this complex number
	public Complex subtract(Complex b) {
		Complex sub = new Complex();
		sub.real = real - b.real;
		sub.imaginary = imaginary - b.imaginary;
		return sub;
	}//end of method

	// Multiply a complex number by this complex number
	public Complex multiply(Complex b) {
		Complex times = new Complex();
		times.real =(( real * b.real) - (imaginary *b.imaginary));
		times.imaginary = ((imaginary * b.real) + (real * b.imaginary));
		return times;
	}//end of method

	// Divide a complex number by this complex number
	public Complex divide(Complex b) {
		Complex div = new Complex();
		div.real = Math.round((( real * b.real) + (imaginary *b.imaginary))/ (Math.pow(b.real,2) + (Math.pow(b.imaginary,2)))) ;
		div.imaginary = Math.round(((imaginary * b.real) + (real * b.imaginary))/ (Math.pow(b.real,2) + (Math.pow(b.imaginary,2))));
		return div;
	}//end of method

	// Returns the absolute value of this complex number 
	public double abs() {
		return Math.round(Math.sqrt(Math.pow(real, 2) + Math.pow(imaginary, 2)));
	}//end of method
	
   //method that clones
	public Complex clone() throws CloneNotSupportedException {
		return (Complex)super.clone();
	}//end of method

   //returns a string description of the complex number
	public String toString() {
		return "(" + real+ " + " + imaginary + "i)";
	}//end of method
}//end of class
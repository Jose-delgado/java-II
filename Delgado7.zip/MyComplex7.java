/*************************************************************************
 *Purpose:     is the tester for MyComplex7
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        10/13/2017  
 *************************************************************************   
 */
//name of class
public class MyComplex7 {
   //begin of main method
	public static void main(String[] args) throws CloneNotSupportedException {
      //declaration fields
   	double a = Double.parseDouble(args[0]);
		double b = Double.parseDouble(args[1]);
		double c = Double.parseDouble(args[2]);
		double d = Double.parseDouble(args[3]);
		
      //sets complex numbers from the variables
		Complex complexNumber1 = new Complex(a,b);
		Complex complexNumber2 = new Complex(c,d);

		// displays the result of their addition, subtraction,multiplication, division, and absolute value
		System.out.println(complexNumber1 + " + " + complexNumber2 + " = " + complexNumber1.add(complexNumber2));
		System.out.println(complexNumber1 + " - " + complexNumber2 + " = " + complexNumber1.subtract(complexNumber2)); 
		System.out.println(complexNumber1 + " * " + complexNumber2 + " = " + complexNumber1.multiply(complexNumber2)); 
		System.out.println(complexNumber1 + " / " + complexNumber2 + " = " + complexNumber1.divide(complexNumber2)); 
		System.out.println("|" + complexNumber1 + "| = " + 
			complexNumber1.abs());
	}//end of main method
}//end of class
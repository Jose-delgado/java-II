//*******************************************************************************
//Purpose:  To go through multiple lists with different types using generic it
//          is able to use the numerous lists for multiple methods
//
//Author:   Jose Delgado
//
//Course: 	1302 Section B fall
//
//Date: 	10/16/2017
//
//Program:  MyGenerics8.java
//*******************************************************************************

//import java utilities
import java.util.*;
//name of class
public class MyGenerics8{
   //Declarations
   
   
   //****************************************************************************
   //No-argument constructor:
   //****************************************************************************
   public MyGenerics8 (){
   
   }//end of constructor
   
   //****************************************************************************
   //max:   Receives a generic one-dimensional array and returns the maximum
   //       value in the array.
   //****************************************************************************
   public <E extends Comparable<E>> E max(E[] list){
	   //sets max to the first address from list
      E max = list[0];
      //goes through the list
      for(int i = 0; i < list.length; i++)
    	  //compares whatever is in list and checks if it is larger than 0
         if(list[i].compareTo(max) > 0)
        	 //if true assigns whatever is in list to max
            max = list[i];
      //returns max
      return max;
    }//end of method
    
   //****************************************************************************
   //max:   Receives a generic two-dimensional array and returns the maximum
   //       value in the array.
   //****************************************************************************
   public <E extends Comparable<E>> E max(E[][] list) {
	//sets max to the address of 00 
	E max = list[0][0];
	//for loop that goes throguh the first list
   for(int r = 0; r < list.length; r++)
	   //nested for loop that goes through the second list
      for(int c = 0; c < list[r].length; c++)
    	  //if statement that compares whatever are in lists to max and 
    	  //checks if it is larger than 0
         if(list[r][c].compareTo(max) > 0)
         //sets max if it is true
         max = list[r][c];
   	  //returns max
      return max;
   }//end of method
   
   //****************************************************************************
   //largest:     Receives a generic arrayList and returns the maximum
   //             value in the array.
   //****************************************************************************
   public <E extends Comparable<E>> E largest(ArrayList<E> list) {
	   //gets the first address of the arraylist
      E largest = list.get(0);
      //goes through the arrayList
      for(int i = 0; i < list.size(); i ++)
    	  //compares whatever is in list to the largest and checks if it is larger than 0
         if(list.get(i).toString().compareTo(largest.toString()) > 0)
        	 //sets largest to watever is in list
         largest = list.get(i);
      //return the largest
      return largest;
   }//end of method
    
   //****************************************************************************
   //binarySearch:     Receives a generic one-dimensional array and a generic key
   //                  and returns the location of the key (positive) or
   //                  a negative location if not found.
   //****************************************************************************
   public <E extends Comparable<E>> int binarySearch(E[] list, E key) {
      int low = 0;
      int high = list.length - 1;
      return binarySearch (list, key, low, high);
   }
   
   public <E extends Comparable<E>> int binarySearch(E[] list, E key, int low, int high) {
	   	  //if statement that compares low to high and returns the negative of low -1
	      if( low > high  )
	          return -low-1;
	      //gets mid
	      int mid = (high+low)/2;
	      //compares key to list with mid in it and checks if it is larger than 0
	      if( key.compareTo( list[mid] ) > 0 )
	    	  //implements recursive with passing the higher 
	          return binarySearch(list, key, mid+1, high);
	      //else if statement that compares the key and checks if it is lower than 0
	      else if( key.compareTo( list[mid] ) < 0 )
	    	  //implements recursive with passing the lower
	          return binarySearch( list, key, low, mid-1 );
	      // if it is anything else returns the mid
	      else
	          return mid; 
   }//end of method

   //****************************************************************************
   //sort:     Receives a generic arrayList and returns nothing.
   //****************************************************************************
   public <E extends Comparable<E>> void sort(ArrayList<E> list) {
	   //for loop that goes through the lists
	   for(int i = 0; i < list.size();i++) {
		   //method that sorts the lists
		   Collections.sort(list);
	   }//end of for loop
   }// end of method

   //****************************************************************************
   //uniqueItems:    Receives a generic one-dimensional array and removes
   //                the duplicate values in it.When done, it returns 
   //                ArrayList of type generic that contains only the unique values
   //****************************************************************************
   public <E extends Comparable<E>> ArrayList<E> uniqueItems(E[] list) {
	   //creates a new arrayList
	   ArrayList<E> a = new ArrayList<E>();
	   //for each loop 
	   for (E items : list) {
		   	//if statements that compares
	    	if(!a.contains(items)){
	    		//adding items that are not in the new arrayList
	    		a.add(items);
	    	}//end of if statement
	    }//end of for loop
	    return a;
   }//end of method

   //****************************************************************************
   //sort:     Receives a generic one-dimensional array and returns nothing.
   //****************************************************************************
   public <E extends Comparable<E>> void sort(E[] list) {
	   System.out.println();
	   //for loop that goes through the lists
	   for(int i = 0; i < list.length; i++) {
		   Arrays.sort(list);
	   }//end of for loop
   }//end of method
  
   //****************************************************************************
   //displayOneDList:     Receives a generic one-dimensional array and displays its contents
   //****************************************************************************
   public <E> void displayOneDList(E[] list, String listName){
	   //prints out the lists names
	   System.out.print("\n" + listName + "\n");
	   //for loop that goes through the lists
	   for(int i = 0; i < list.length; i++) {
		   System.out.print("\t" + list[i]);
	   }//end of for loop
	   System.out.print("\n\n");
   } //end of method


   //****************************************************************************
   //displayTwoDList:     Receives a generic two-dimensional array & a string name
   //                     and displays its contents
   //****************************************************************************
   public <E> void displayTwoDList(E[][] list, String listName){
	  System.out.print("\n" + listName + "\n");
	  //for loop that goes through the lists
	  for(int r = 0; r < list.length; r++) {
		  System.out.print("\t" + (r+1));
		  //nested for loop that goes through the second list
		  for(int c = 0; c < list[r].length; c++) {
			  System.out.print("\t" + list[r][c].toString());
			  //if statements that sees how long the address are 
			  //and prints out the spacing
			  if(list[r][c].toString().length() <=7 ) {
				  System.out.print("\t");
			  }//end of if statement
		  }//end of nested for loop
		  System.out.print("\n\n");
	  }//end of for loop
   }//end of method 

   //****************************************************************************
   //displayArrayList:     Receives a generic arraylist & a string name
   //                      and displays its contents
   //****************************************************************************
   public <E> void displayArrayList(ArrayList <E> list, String listName){
	   //displaying list name
	   System.out.print("\n"+ listName + "\n");
	   //goes throguh the list and prints it
	   for(int i = 0; i < list.size();i++) {
		   System.out.print("\t" + list.get(i));
	   }//end of for loop
	   System.out.print("\n\n");
   } //end of method
}//end of class
//*******************************************************************************
//Purpose:  To Evaluate infix and postfix expressions from the command line
//          and calculate the results
//
//Author:   Jose Delgado
//
//Course:   1302 Section B fall
//
//Date:     10/16/2017
//
//Program:  MyExpression9.java
//*******************************************************************************

//importing stack utilities
import java.util.Stack;
//name of class
public class MyExpression9{
  //begin of main method
  public static void main(String[] args) {
    //if statement that Checks number of elements in args if lower than one
    if (args.length < 1) {
      System.out.println(
        "Usage: java EvaluateExpression \"expression\"");
      System.exit(1);
    }//end of if statement
      
    // for loop to go through the command line  
    for (int i = 0; i < args.length; i++){
      //switch statement used to determine the order
      switch(i){
         //first case
         case 0: try {
                     System.out.println(args[0] + "= " + evaluateExpression(args[0]));
                     break;//break through
                 }//end of case
                 
                 catch (Exception ex){//catch the exception if it occurs
                     System.out.println("Wrong expression: " + args[0]);    
                 }//end of catch
                 
         //second case        
         case 1: try {
                     System.out.println(args[1] + "= " + evaluateExpression(args[1]));
                     //break through the loop
                     break;
                    }//end of case
                    
                 catch (Exception ex){//catch the exception if it occurs
                     System.out.println("Wrong expression: " + args[1]);
                 }//end of catch
                 
         //third case        
         case 2: try {//third argument
                     System.out.println(args[2] + "= " + evaluateExpression2(args[2]));
                     //break through the loop
                     break;
                 }//end of case
                 catch (Exception ex){//catch the exception if it occurs
                     System.out.println("Wrong expression: " + args[2]);     
                 }//end of catch
                 
         //4th case        
         case 3: try {
                     System.out.println(args[3] + "= " + evaluateExpression2(args[3]));
                     //break through the loop
                     break;
                 }//end of case
                 catch (Exception ex){//catch the exception if it occurs
                     System.out.println("Wrong expression: " + args[3]);
                 }//end of catch
         default: continue;
     }//end of switch
    }//end of for loop  
  }//end of main

  /** Evaluate an expression */
  public static int evaluateExpression(String expression) {
    // Create operandStack to store operands
    Stack<Integer> operandStack = new Stack<Integer>();
  
    // Create operatorStack to store operators
    Stack<Character> operatorStack = new Stack<Character>();
  
    // Insert blanks around (, ), ^,  +, -, /, % and *
    expression = insertBlanks(expression);

    // Extract operands and operators
    String[] tokens = expression.split(" ");

    // Phase 1: Scan tokens
    for (String token: tokens) {
      if (token.length() == 0) // Blank space
        continue; // Back to the while loop to extract the next token
      else if (token.charAt(0) == '+' || token.charAt(0) == '-') {
        // Process all +, -, *, /, %, ^ in the top of the operator stack 
        while (!operatorStack.isEmpty() &&
          (operatorStack.peek() == '+' || 
           operatorStack.peek() == '-' ||
           operatorStack.peek() == '^' ||
           operatorStack.peek() == '*' ||
           operatorStack.peek() == '/' ||
           operatorStack.peek() == '%' )) {
          processAnOperator(operandStack, operatorStack);
        }//end of while loop

        // Push the + or - operator into the operator stack
        operatorStack.push(token.charAt(0));
      }//end of else is statement


      //else if statement that sees if it has any of these operators *, / or %
      else if (token.charAt(0) == '^') {
        // Process all ^ in the top of the operator stack 
        while (!operatorStack.isEmpty() &&
          (operatorStack.peek() == '^')) {
          processAnOperator(operandStack, operatorStack);
        }//end of while loop

        // Push the ^ operator into the operator stack
        operatorStack.push(token.charAt(0));
      }//end of else if statement
     
      //else if statement that sees if it has any of these operators *, / or %
      else if (token.charAt(0) == '*' || token.charAt(0) == '/' || token.charAt(0) == '%') {
        // Process all *, /, % in the top of the operator stack 
        while (!operatorStack.isEmpty() &&
          (operatorStack.peek() == '%' ||
           operatorStack.peek() == '*' ||
           operatorStack.peek() == '/' )) {
          processAnOperator(operandStack, operatorStack);
        }//end of while loop

        // Push the *, /, or % operator into the operator stack
        operatorStack.push(token.charAt(0));
      }//end of else if statement
		
      else if (token.trim().charAt(0) == '(') {
        operatorStack.push('('); // Push '(' to stack
      }//end of else if statment
      else if (token.trim().charAt(0) == ')') {
        // Process all the operators in the stack until seeing '('
        while (operatorStack.peek() != '(') {
          processAnOperator(operandStack, operatorStack);
        }//end of while loop
        operatorStack.pop(); // Pop the '(' symbol from the stack
      }//end of else if statement
      else { // An operand scanned
        // Push an operand to the stack
        operandStack.push(new Integer(token));
      }//end of else statement
    }//end of for each loop

    // Phase 2: process all the remaining operators in the stack 
    while (!operatorStack.isEmpty()) {
      processAnOperator(operandStack, operatorStack);
    }//end of while loop

    // Return the result
    return operandStack.pop();
  }//end of evaluateExpression method
  
  /** Process one operator: Take an operator from operatorStack and
   *  apply it on the operands in the operandStack */
  public static void processAnOperator(
      Stack<Integer> operandStack, Stack<Character> operatorStack) {
    char op = operatorStack.pop();
    int op1 = operandStack.pop();
    int op2 = operandStack.pop();
    if (op == '+') 
      operandStack.push(op2 + op1);
    else if (op == '-') 
      operandStack.push(op2 - op1);
    else if (op == '*')
       operandStack.push(op2 * op1);
    else if (op == '/')
      operandStack.push(op2 / op1);
    else if (op == '%')
      operandStack.push(op2 % op1);
    else
      operandStack.push((int) Math.pow(op2, op1));
  }//end of processAnOperator method
  
  //start of second evaluation method
  public static int evaluateExpression2(String expression) {
    // Create operandStack to store operands
    Stack<Integer> operandStack = new Stack<Integer>();
  
    // Create operatorStack to store operators
    Stack<Character> operatorStack = new Stack<Character>();
  
    // Insert blanks around (, ), +, -, /, and *
    expression = insertBlanks(expression);

    // Extract operands and operators
    String[] tokens = expression.split(" ");
    
    //scan tokens
    for (String token : tokens){
    //if token is a space
      if(token.length() == 0)
         continue;
      else if (token.charAt(0) == '+' || token.charAt(0) == '-' ||
               token.charAt(0) == '*' || token.charAt(0) == '/' ||
               token.charAt(0) == '%' || token.charAt(0) == '^' ){
         operatorStack.push(token.charAt(0));
         processAnOperator(operandStack, operatorStack);
      }//end of else if
      
      else//else (if token is an operand)
         operandStack.push(new Integer(token));
         }
    //return the result
    return operandStack.peek();   
    }//end of evalueateExpression2    
  
  //String method that adds blank spaces
  public static String insertBlanks(String s) {
    String result = "";
    //for loop that goes through the string and checks for the operator characters
    for (int i = 0; i < s.length(); i++) {
      if (s.charAt(i) == '(' || s.charAt(i) == ')' || 
          s.charAt(i) == '^' || s.charAt(i) == '%' ||
          s.charAt(i) == '+' || s.charAt(i) == '-' ||
          s.charAt(i) == '*' || s.charAt(i) == '/' )
        result += " " + s.charAt(i) + " ";
      else
        result += s.charAt(i);
    }//end of for loop
    
    //returns the result
    return result;
  }//end of String method
}//end of class
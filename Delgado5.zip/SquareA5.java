/*************************************************************************
 *Purpose:     to do numerous methods with a square also extends Rectangle
 *             1. gets one side
 *             2. calculates area and perimeter through super
 *             3. prints the rest of the information
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */

//begin of class
public class SquareA5 extends RectangleA5 {
	//data field for variable side
	private double side;
	
	//nor argument constructor
	public SquareA5() {
	}//end of no argument costructor
	
	//argument constructor
	public SquareA5(double side) {
		super (side, side);
		this.side = side;
	}//end of method
	
	//argument constuctor
	public SquareA5(double side, String color, boolean filled) {
		this.side = side;
		setColor(color);
		setFilled(filled);
	}//end of method

	//method to print all the information of the squares
	public String toString() {
		return "\n\t Square Information" + 
				"\n color: " + getColor() + 
				"\n Filled: " + isFilled() + 
				"\n created on " + getDateCreated() + 
				"\n Side is: \t" + fmt.format(side) +
				"\n Area is: \t"  + fmt.format(getArea()) +
				"\n Perimeter is: \t" + fmt.format(getPerimeter());		
		}//end of method
}//end of class

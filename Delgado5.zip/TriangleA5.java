/*************************************************************************
 *Purpose:     to do numerous methods with a Triangle
 *             1. gets the sides
 *             2. sets the area
 *             3. gets the perimeter of the triangles
 *             4. prints the rest of the information for the triangles
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */

//begining of of class
public class TriangleA5 extends GeometricObjectAbstract5 {
	//declaring data types/variables
	private double side1 = 1;
	private double side2 = 1;
	private double side3 = 1;

	//nor arguemtent contructor
	public TriangleA5 () {
		
	}//end of no argument constructor
	
	//argument constructor 
	public TriangleA5(double side1, double side2, double side3) {
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}//end of argument constructor
	
	//argument constructor
	public TriangleA5(
		double side1, double side2, double side3 , String color, boolean filled) {
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
		setColor(color);
		setFilled(filled);
		  }//end of method
	
	//creating getter for side 1
	public double getSide1() {
		return side1;
	}//end of method

	//setter method for side 1
	public void setSide1(double side1) {
		this.side1 = side1;
	}//end of method

	//creating getter for side 2
	public double getSide2() {
		return side2;
	}//end of method

	//setter method for side 2
	public void setSide2(double side2) {
		this.side2 = side2;
	}//end of method

	//creating getter for side 3
	public double getSide3() {
		return side3;
	}//end of method

	//setter method for side 3
	public void setSide3(double side3) {
		this.side3 = side3;
	}//end of method

	//begin of method that returns area
	@Override
	public double getArea() {
		double preArea = (side1 + side2 + side3)/2;
		double area = Math.sqrt(preArea * (preArea -side1)*(preArea -side2)*
				(preArea -side3)); 
		return area;
	}//end of method

	//begin of method that returns perimeter
	@Override
	public double getPerimeter() {
		double perimeter = (side1 + side2 + side3);
		return perimeter;	
	}//end of method
	
	//method to return all the information
	public String toString() {
		return "\n\t Triangle Information" + "\n\tcreated on " + getDateCreated() + 
				"\n color: " + getColor() + " and filled: " + isFilled() + 
				"\n Side1 is: \t" + fmt.format(side1) +
				"\n Side2 is: \t" + fmt.format(side2) +
				"\n Side3 is: \t" + fmt.format(side3) +
				"\n Area is: \t"  + fmt.format(getArea()) +
				"\n Perimeter is: \t" + fmt.format(getPerimeter());
		  }//end of method
}//end of class

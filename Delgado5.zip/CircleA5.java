/*************************************************************************
 *Purpose:     to do numerous methods with a circle
 *             1. gets the radius
 *             2. sets the area
 *             3. gets the perimeter of the circles
 *             4. prints the rest of the information for the circles
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */
public class CircleA5 
    extends GeometricObjectAbstract5 {
	
	//data field variable for radius
  private double radius;

  public CircleA5() {
  }//end of method

  public CircleA5(double radius) {
    this.radius = radius;
  }//end of method

  public CircleA5(double radius, 
      String color, boolean filled) {
    this.radius = radius;
    setColor(color);
    setFilled(filled);
  }//end of method

  /** Return radius */
  public double getRadius() {
    return radius;
  }//end of method

  /** Set a new radius */
  public void setRadius(double radius) {
    this.radius = radius;
  }//end of method

  /** Return area */
  public double getArea() {
    return radius * radius * Math.PI;
  }//end of method
  
  /** Return diameter */
  public double getDiameter() {
    return 2 * radius;
  }//end of method
  
  /** Return perimeter */
  public double getPerimeter() {
    return 2 * radius * Math.PI;
  }//end of method

  /* Print the circle info */
	public String toString() {
		return "\n\t Circle Information" + "\n\tcreated on " + getDateCreated() + 
				"\n color: " + getColor() + " and filled: " + isFilled() + 
				"\n Radius is: \t" + fmt.format(getRadius()) +
				"\n Area is: \t"  + fmt.format(getArea()) +
				"\n Perimeter is: \t" + fmt.format(getPerimeter());		
		  }//end of method
}//end of class

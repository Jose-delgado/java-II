/*************************************************************************
 *Purpose:     to do numerous methods with rectangles and is parent class of square
 *             1. gets the width, and height
 *             2. sets the area
 *             3. gets the perimeter of the rectangles
 *             4. prints the rest of the information
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */

//begin of class
public class RectangleA5 
    extends GeometricObjectAbstract5 {
	//data fields
  private double width;
  private double height;
  
  //begin of no arguement constructor 
  public RectangleA5() {
  }//end of method

  //begin of argument constructor
  public RectangleA5(
      double width, double height) {
    this.width = width;
    this.height = height;
  }//end of method

  //another argument constructor
  public RectangleA5(
      double width, double height, String color, boolean filled) {
    this.width = width;
    this.height = height;
    setColor(color);
    setFilled(filled);
  }//end of constructor method

  /** Return width */
  public double getWidth() {
    return width;
  }//end of method

  /** Set a new width */
  public void setWidth(double width) {
    this.width = width;
  }//end of method

  /** Return height */
  public double getHeight() {
    return height;
  }//end of method

  /** Set a new height */
  public void setHeight(double height) {
    this.height = height;
  }//end of method

  /** Return area */
  public double getArea() {
    return width * height;
  }//end of method

  /** Return perimeter */
  public double getPerimeter() {
    return 2 * (width + height);
  }//end of method
  
  	//method to print all the information
	public String toString() {
		return "\n\t Rectangle Information" + "\n\tcreated on " + getDateCreated() + 
				"\n color: " + getColor() + " and filled: " + isFilled() + 
				"\n Width is: \t" + fmt.format(getWidth()) +
				"\n Height is: \t" + fmt.format(getHeight()) +
				"\n Area is: \t"  + fmt.format(getArea()) +
				"\n Perimeter is: \t" + fmt.format(getPerimeter());		
		  }//end of method
}//end of class

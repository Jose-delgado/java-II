/*************************************************************************
 *Purpose:     tester for all the classes
 *             1. creates an array list of objects
 *             2. displays size of the arraylist
 *             3. calculates total area and perimeter and sets a default value
 *             4. calculates the total area and perimeter
 *             5. prints out the total area and perimeter
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */
import java.util.*;
//begin of class
public class MyShapesAbstract5 {
	//begin of main method
  public static void main(String[] args) {
   //Create an ArrayList
   ArrayList <GeometricObjectAbstract5> shapes = new ArrayList<>();
   
   //Insert shapes into ArrayList
   shapes.add (new CircleA5());
   shapes.add (new RectangleA5());
   shapes.add (new SquareA5(10));
   shapes.add (new TriangleA5());
   shapes.add (new CircleA5(10));
   shapes.add (new RectangleA5(5,10));
   shapes.add (new TriangleA5(3,4,5));
   shapes.add (new SquareA5(3));
   
   //Display the shapes in the ArrayList
   for (int i = 0; i < shapes.size(); i++)
      System.out.println (shapes.get(i));


   //Display the number of each shape type (Circle, Rectangle, Sqaure, and Triangle)
   //Display the total area of each shape type (Circle, Rectangle, Square, and Triangle)
   //Display the total perimeter of all shapes.
  
   double totalPerimeters = 0;
   double totalAreas = 0;
   
   for (int i = 0; i < shapes.size(); i++){
      GeometricObjectAbstract5 go = shapes.get(i);
      totalPerimeters += go.getPerimeter();
       totalAreas += go.getArea();
   }//end of for loop
     
   //print statements to print the total area and perimeter
   System.out.printf ("\n\n\n\t%-30s%13.2f","Total of all perimeters",totalPerimeters);
   System.out.printf ("\n\n\n\t%-30s%13.2f","Total of all areas",totalAreas);


  }//end of main method
}//end of class
/*************************************************************************
 *Purpose:     parents class that extends to the other class
 *             1. date, color and fill
 *             2. get/set color
 *             3. abstract method for area
 *             4. abstract method for perimeter
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        9/26/2017  
 *************************************************************************   
 */
import java.text.DecimalFormat;
public abstract class GeometricObjectAbstract5 {
	//data fields
  private String color = "white";
  private boolean filled;
  private java.util.Date dateCreated;
  
  //implementing decimal format in order to adjust the size of the output
  DecimalFormat fmt = new DecimalFormat("#.##");
  
  /** Construct a default geometric object */
  public GeometricObjectAbstract5() {
    dateCreated = new java.util.Date();
  }//end of method

  /** Construct a geometric object with the specified color 
    *  and filled value */
  public GeometricObjectAbstract5(String color, boolean filled) {
    dateCreated = new java.util.Date();
    this.color = color;
    this.filled = filled;
  }//end of method

  /** Return color */
  public String getColor() {
    return color;
  }//end of method

  /** Set a new color */
  public void setColor(String color) {
    this.color = color;
  }//end of method

  /** Return filled. Since filled is boolean, 
     its get method is named isFilled */
  public boolean isFilled() {
    return filled;
  }//end of meeting

  /** Set a new filled */
  public void setFilled(boolean filled) {
    this.filled = filled;
  }//end of meeting
  
  /** Get dateCreated */
  public java.util.Date getDateCreated() {
    return dateCreated;
  }//end of method
  
  //abstract method to get area
  public abstract double getArea();
  
  //abstract method to get the perimeter
  public abstract double getPerimeter();
  
  
  /** Return a string representation of this object */
  public String toString() {
    return "created on " + dateCreated + "\ncolor: " + color + 
      " and filled: " + filled;
  }//end of method
}//end of class
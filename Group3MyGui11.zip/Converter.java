/********************************************************
*      purpose:   practice with GUI's and to create windows 
*                 used to help convert Kilometers to miles
*                 and vice versa
*      
*      Authors:   Wallace Coleman and Jose Delgado
*      
*      class:     CS 1302 Section B Fall
*      
*      Date:      11/26/2017
*********************************************************/

//importing everything necessary
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.geometry.Pos;
import javafx.scene.input.KeyCode;

//declaring of class
public class Converter extends Application {
   //declarations
	private double KILOMETERS_PER_MILE = 1.602307322544464;
	private TextField tfMile = new TextField();
	private TextField tfKilometer = new TextField();

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Sets the aligment for the twi text fields
		tfMile.setAlignment(Pos.BOTTOM_RIGHT);
		tfKilometer.setAlignment(Pos.BOTTOM_RIGHT);

		// Create a gridpane and adding labels and text fields
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.add(new Label("Mile"), 0, 0);
		pane.add(tfMile, 1, 0);
		pane.add(new Label("Kilometer"), 0, 1);
		pane.add(tfKilometer, 1, 1);

		// creating and using handler
		tfMile.setOnKeyPressed(e -> {
         // if statement that calculates miles to kilometers if enter is pressed 
         // and the length is larger than 0
			if (e.getCode() == KeyCode.ENTER && tfMile.getText().length() > 0) {
				double miles = Double.parseDouble(tfMile.getText());
				tfKilometer.setText(String.valueOf(miles * KILOMETERS_PER_MILE));
			}
		});

      // creating and using handler
		tfKilometer.setOnKeyPressed(e -> {
         // if statement that calculates kilometers to miles if enter is pressed 
         // and the length is larger than 0
			if (e.getCode() == KeyCode.ENTER && tfKilometer.getText().length() > 0) {
				double kilometers = Double.parseDouble(tfKilometer.getText());
				tfMile.setText(String.valueOf(kilometers / KILOMETERS_PER_MILE));
			}
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 250, 60);
      // Set the stage title
		primaryStage.setTitle("Miles/Kilometers Converter");
      // Place the scene in the stage 
		primaryStage.setScene(scene); 
      // Display the stage
		primaryStage.show(); 
	}//end of method
}//end of class
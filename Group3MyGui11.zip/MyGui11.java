/********************************************************
*      purpose:   practice with GUI's and to create windows with 
*                 graphics such as creating shapes at the press 
*                 of a button or changing color of text and mvoing it
*      
*      Authors:   Wallace Coleman and Jose Delgado
*      
*      class:     CS 1302 Section B Fall
*      
*      Date:      11/26/2017
*********************************************************/

//importing everything needed
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javafx.scene.control.CheckBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Ellipse;

//declaration of class
public class MyGui11 extends Application {
   //declaration field
	private Text text = new Text(175, 50, "Programming is fun");
	private Circle circle = new Circle(50);	// Create a circle
	private Rectangle rectangle = new Rectangle(); // Create a Rectangle
	private Ellipse ellipse = new Ellipse(); // Crate an Ellipse
  
	@Override // Override the stage method in the Application class
	public void start(Stage primaryStage) {
   
      //creating a new HBox to hold the two left and right buttons
		HBox paneForButtons = new HBox(1);
		Button btLeft = new Button("<=");
		Button btRight = new Button(">=");
		paneForButtons.getChildren().addAll(btLeft, btRight);
		paneForButtons.setAlignment(Pos.CENTER);
		BorderPane pane = new BorderPane();
		pane.setBottom(paneForButtons);
   
      //creating a new HBox to hold the color buttons
		HBox paneForRadioButtons = new HBox(5);
		RadioButton rbRed = new RadioButton("Red");
		RadioButton rbYellow = new RadioButton("Yellow");
		RadioButton rbBlack = new RadioButton("Black");
		RadioButton rbOrange = new RadioButton("Orange");
		RadioButton rbGreen = new RadioButton("Green");
      paneForRadioButtons.setAlignment(Pos.CENTER);
		paneForRadioButtons.getChildren().addAll(rbRed, rbYellow, 
			rbBlack, rbOrange, rbGreen);

      //toggle group to make sure the other buttons are deselected
		ToggleGroup group = new ToggleGroup();
		rbRed.setToggleGroup(group);
		rbYellow.setToggleGroup(group);
		rbBlack.setToggleGroup(group);
		rbOrange.setToggleGroup(group);
		rbGreen.setToggleGroup(group);

      //creating a pane to add everything
		Pane paneForText = new Pane();
		paneForText.setStyle("-fx-border-color: black");
		paneForText.getChildren().add(text);
		pane.setCenter(paneForText);
		pane.setTop(paneForRadioButtons);
   
      //in order to move the text left or to the right
		btLeft.setOnAction(e -> text.setX(text.getX() - 10));
		btRight.setOnAction(e -> text.setX(text.getX() + 10));

      // creating and using handler
		rbRed.setOnAction(e -> {
         //if statement that sets the text color to red 
			if (rbRed.isSelected()) {
				text.setFill(Color.RED);
			}
		});

      // creating and using handler
		rbYellow.setOnAction(e -> {
         //if statement that sets the text color to yellow
			if (rbYellow.isSelected()) {
				text.setFill(Color.YELLOW);
			}
		});

      // creating and using handler
		rbBlack.setOnAction(e -> {
         //if statement that sets the text color to black
			if (rbBlack.isSelected()) {
				text.setFill(Color.BLACK);
			}
		});

      // creating and using handler
		rbOrange.setOnAction(e -> {
         //if statement that sets the text color to orange 
			if (rbOrange.isSelected()) {
				text.setFill(Color.ORANGE);
			}
		});

      // creating and using handler
		rbGreen.setOnAction(e -> {
         //if statement that sets the text color green
			if (rbGreen.isSelected()) {
				text.setFill(Color.GREEN);
			}
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 450, 150);
      // Set title of the title/stage
		primaryStage.setTitle("My Radio Buttons"); 
      // Place the scene in the stage
		primaryStage.setScene(scene);
      // Display the stage 
		primaryStage.show(); 
      
      
/***************************************************************************************
*
*                       Begin of shapes 
*
***************************************************************************************/

      //creating numerous objects with select properties
		circle.setStroke(Color.BLACK);
		circle.setFill(Color.WHITE);
		rectangle.setStroke(Color.BLACK);
		rectangle.setWidth(150);
		rectangle.setFill(Color.WHITE);
		rectangle.setHeight(100);
		ellipse.setFill(Color.WHITE);
		ellipse.setStroke(Color.BLACK);
		ellipse.setRadiusX(100);
		ellipse.setRadiusY(50);

		// Creating a HBox to hold buttons
		HBox buttonHolder = new HBox(5);
		buttonHolder.setAlignment(Pos.CENTER);
		RadioButton rbCircle = new RadioButton("Circle"); 
		RadioButton rbRectangle = new RadioButton("Rectangle"); 
		RadioButton rbEllipse = new RadioButton("Ellipse"); 

		// Create a toggle group for shapes to make sure others are deslected
		ToggleGroup toggle = new ToggleGroup();
		rbCircle.setToggleGroup(toggle);
		rbRectangle.setToggleGroup(toggle);
		rbEllipse.setToggleGroup(toggle);

		// Create a check box called fill
		CheckBox chkFill = new CheckBox("Fill");

		// Place the buttons in the HBox
		buttonHolder.getChildren().addAll(rbCircle, 
			rbRectangle, rbEllipse, chkFill);

		// Create a Stackpane to create the space for the shapes
		StackPane paneForShapes = new StackPane();
		paneForShapes.setStyle("-fx-border-color: black");

		// Creating a BorderPane to set the buttons 
		BorderPane border = new BorderPane();
		border.setBottom(buttonHolder);
		border.setCenter(paneForShapes);

      // creating and using handler
		rbCircle.setOnAction(e -> {
         // if statment to create circle
			if (rbCircle.isSelected()) {
				paneForShapes.getChildren().clear();
				paneForShapes.getChildren().add(circle);
			}
		});

      // creating and using handler
		rbRectangle.setOnAction(e -> {
         // if statment to create rectangle
			if (rbRectangle.isSelected()) {
				paneForShapes.getChildren().clear();
				paneForShapes.getChildren().add(rectangle);
			}
		});

      // creating and using handler
		rbEllipse.setOnAction(e -> {
         // if statment to create ellipse
			if (rbEllipse.isSelected()) {
				paneForShapes.getChildren().clear();
				paneForShapes.getChildren().add(ellipse);
			}
		});

      // creating and using handler
		chkFill.setOnAction(e -> {
         //if statement that fills the objects with black color
			if (chkFill.isSelected()) {
				circle.setFill(Color.BLACK);
				rectangle.setFill(Color.BLACK);
				ellipse.setFill(Color.BLACK);
			} else {//else if statment that fills the object with white color
				circle.setFill(Color.WHITE);
				rectangle.setFill(Color.WHITE);
				ellipse.setFill(Color.WHITE);			}
		});

		// Create a scene and place it in the stage
		Scene shape = new Scene(border, 400, 150);
      Stage shapes = new Stage();
      // Set the stage title
		shapes.setTitle("shapes");
      // Place the scene in the stage 
		shapes.setScene(shape);
      // Display the stage 
		shapes.show(); 
//*****************************************************************************************
	}//end method
   
   public static void main(String [] args){
      launch(args);
   }//end of main method
}//end of class
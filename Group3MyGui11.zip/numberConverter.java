/********************************************************
*      purpose:   practice with GUI's and to create windows 
*                 used to help convert a number into its
*                 corresponding hex key and binary number
*                 and vice versa
*      
*      Authors:   Wallace Coleman and Jose Delgado
*      
*      class:     CS 1302 Section B Fall
*      
*      Date:      11/26/2017
*********************************************************/

//importing everything necessary
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.geometry.Pos;
import javafx.scene.input.KeyCode;

//declaration of class
public class numberConverter extends Application {
	protected TextField tfDecimal = new TextField();
	protected TextField tfHex = new TextField();
	protected TextField tfBinary = new TextField();

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Seting the aligment of the textfields
		tfDecimal.setAlignment(Pos.BOTTOM_RIGHT);
		tfHex.setAlignment(Pos.BOTTOM_RIGHT);
		tfBinary.setAlignment(Pos.BOTTOM_RIGHT);

		// Creating a GridPane and adding labels and textfields
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		pane.setHgap(10);
		pane.setVgap(2);
		pane.add(new Label("Decimal"), 0, 0);
		pane.add(tfDecimal, 1, 0);
		pane.add(new Label("Hex"), 0, 1);
		pane.add(tfHex, 1, 1);
		pane.add(new Label("Binary"), 0, 2);
		pane.add(tfBinary, 1, 2);

		// creating and using handler
		tfDecimal.setOnKeyPressed(e -> {
         // if statment that accepts a decimal and returns a hex and its binary number
			if (e.getCode() == KeyCode.ENTER) {
				tfHex.setText(Integer.toHexString(
					Integer.parseInt(tfDecimal.getText())));

				tfBinary.setText(Integer.toBinaryString(
					Integer.parseInt(tfDecimal.getText())));
			}
		});

      // creating and using handler
		tfHex.setOnKeyPressed(e -> {
         // if statment that accepts a hex and returns its decimal and binary number
			if (e.getCode() == KeyCode.ENTER) {
				tfDecimal.setText(String.valueOf(
					Integer.parseInt(tfHex.getText(), 16)));

				tfBinary.setText(Integer.toBinaryString(
					Integer.parseInt(tfHex.getText(), 16)));
			}
		});

      // creating and using handler
		tfBinary.setOnKeyPressed(e -> {
         //if statment that accepts a binary number and converts it to a hex and a decimal
			if (e.getCode() == KeyCode.ENTER) {
				tfDecimal.setText(String.valueOf(
					Integer.parseInt(tfBinary.getText(), 2)));

				tfHex.setText(Integer.toHexString(
					Integer.parseInt(tfBinary.getText(), 2)));
			}
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 250, 100);
      // Set the stage title
		primaryStage.setTitle("numberConverter");
      // Place the scene in the stage
		primaryStage.setScene(scene); 
      // Display the stage
		primaryStage.show(); 
	}//end of method
}//end of class
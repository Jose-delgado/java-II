/********************************************************
*      purpose:   practice with GUI's and to create windows with 
*                 graphics such as a stoplight that changes
*                 colors by using buttons
*      
*      Authors:   Wallace Coleman and Jose Delgado
*      
*      class:     CS 1302 Section B Fall
*      
*      Date:      11/26/2017
*********************************************************/

//importing everything necessary
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.geometry.Pos;

//delcaration of class
public class redLight extends Application {
	@Override // Override the start method in the Application calss
	public void start(Stage primaryStage) {
		// Create a vbox
		VBox paneForCircles = new VBox(5);
		paneForCircles.setAlignment(Pos.CENTER);

		// Create three circles
		Circle c1 = getCircle();
		Circle c2 = getCircle();
		Circle c3 = getCircle();
      //filling the first circle with red
		c1.setFill(Color.RED);

		// Place circles in vbox
		paneForCircles.getChildren().addAll(c1, c2, c3);

		// Creating a rectangle around the circles
		Rectangle rectangle = new Rectangle();
		rectangle.setFill(Color.WHITE);
		rectangle.setWidth(30);
		rectangle.setHeight(100);
		rectangle.setStroke(Color.BLACK);
		rectangle.setStrokeWidth(2);
		StackPane stopSign = new StackPane(rectangle, paneForCircles);

		// Creating a HBox
		HBox paneForRadioButtons = new HBox(5);
		paneForRadioButtons.setAlignment(Pos.CENTER);

		// Creating three radio buttons
		RadioButton rbRed = new RadioButton("Red");
		RadioButton rbYellow = new RadioButton("Yellow");
		RadioButton rbGreen = new RadioButton("Green");

		// Creates a toggle group
		ToggleGroup group = new ToggleGroup();
		rbRed.setToggleGroup(group);
		rbYellow.setToggleGroup(group);
		rbGreen.setToggleGroup(group);
		rbRed.setSelected(true);
		paneForRadioButtons.getChildren().addAll(rbRed, rbYellow, rbGreen);

		// Creates a border pane
		BorderPane pane = new BorderPane();
		pane.setCenter(stopSign);
		pane.setBottom(paneForRadioButtons);

      // creating and using handler
		rbRed.setOnAction(e -> {
         // if statment that turns the first circle red and the rest white
			if (rbRed.isSelected()) {
				c1.setFill(Color.RED);
				c2.setFill(Color.WHITE);
				c3.setFill(Color.WHITE);
			}
		});

      // creating and using handler
		rbYellow.setOnAction(e -> {
         // if statement that turns the second circle yellow and the rest white
			if (rbYellow.isSelected()) {
				c1.setFill(Color.WHITE);
				c2.setFill(Color.YELLOW);
				c3.setFill(Color.WHITE);
			}
		});
   
      // creating and using handler

		rbGreen.setOnAction(e -> {
         //if statement that turns the third circle green and the rest white
			if (rbGreen.isSelected()) {
				c1.setFill(Color.WHITE);
				c2.setFill(Color.WHITE);
				c3.setFill(Color.GREEN);
			}
		});

		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 200, 150);
      // Set the stage title
		primaryStage.setTitle("stopLight"); 
      // Place the scene in the stage
		primaryStage.setScene(scene); 
      // Display the stage
		primaryStage.show(); 
	}

	// Returns a circle 
	private Circle getCircle() {
		Circle c = new Circle(10);
		c.setFill(Color.WHITE);
		c.setStroke(Color.BLACK);
		return c;
	}//end of Circle method
}//end of class
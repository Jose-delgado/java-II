/*************************************************************************
 *Purpose:     to run through a text file and to display the line
 *			   with what corresponds to the user's input
 *
 *Author:      Jose Delgado
 *
 *Course:      CS 1302 Section B
 *
 *Date:        10/2/2017  
 *************************************************************************   
 */

//importing everything that is needed for thing program
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class BookFinder {
	static String fileName,searchString;
	
	//main method that implements the other methods
	public static void main(String [] args) throws FileNotFoundException {
		//method that prompts the user for input
		getUserInputs();
		loadRecords();
		printOutput(searchRecords(loadRecords()));
	}//end of main method
	//method that gets input from the user
	static void getUserInputs() {
		
		//scanner to input from the keyboard
		Scanner input = new Scanner(System.in);
		//prompting user for file name
		System.out.println("Enter the file name:");
		fileName = input.nextLine();
		//prompt the user for more input
		System.out.println("Enter what you are looking for?");
		searchString = input.nextLine();
		//closing the input from the user
		input.close();
	}//end of method
	
	//method that brings in the file with the date type of StringBuilder
	static StringBuilder loadRecords() throws FileNotFoundException {
		StringBuilder fileInfo = new StringBuilder  ();
		try {
			Scanner reader = new Scanner(new File(fileName));
			//while loop to add reader to the StringBuilder fileInfo
			while (reader.hasNextLine()) {
				fileInfo.append(reader.nextLine());
			}// closing while loop
			
			//closing the file
			reader.close();
		}//end of try 
		
		//catching the Exception
		catch(FileNotFoundException ex) {
			ex.printStackTrace();
		}//end of catch method
		//returns the information in StringBuilder format
		return fileInfo;
	}//end of method
		
	//method that searches through the records
	static String [] searchRecords(StringBuilder fileContent) {
		//creating an array called content to hold fileContent
		String [] content = fileContent.toString().split(";");
		//creating a new ArrayList object of type string
		ArrayList <String> list = new ArrayList <String> ();
		//delcaring array of type String
		String [] result;
		//for loop that goes through the files
		for(int i = 0; i < content.length - 1; i++) {
			//if statement that contains searchString in lowercase returns true for next if
			if(content[i].toLowerCase().contains(searchString)) {
				// if statement that adds to the list arrayList
				if(i % 4 == 0) {
					list.add(content[i] + ";" + content[i+1] + ";" + 
						 content[i+2] + ";" + content[i+3]);
				}//end of inner if statement
			}//end if statement
		}//end of for loop
		result = list.toArray(new String[list.size()]);
		//returning records
		return result;
	}//end of method
	
	//package private class that prints out the output
	static void printOutput (String [] foundRecords) {
		System.out.println("Found records:" + foundRecords.length);
		if (foundRecords.length == 0) {
			System.out.println("sorry " + searchString + " not found in " + fileName);
		}//end of if
		//begin of for loop
		for(int i = 0; i < foundRecords.length; i++) {
			System.out.println(foundRecords[i]);
		}//end of for loop
	}//end of method
		
}//end of class
